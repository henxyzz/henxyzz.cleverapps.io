<?php
// Koneksi ke database
include('config.php'); // Pastikan file konfigurasi ini mengandung informasi koneksi ke database

// Cek jika form telah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi form
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error_message = "Semua kolom harus diisi.";
    } elseif ($password !== $confirm_password) {
        $error_message = "Kata sandi dan konfirmasi kata sandi tidak cocok.";
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Cek apakah email sudah terdaftar
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = "Email sudah terdaftar.";
        } else {
            // Insert data pengguna baru ke database
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);
            if ($stmt->execute()) {
                $success_message = "Akun Anda berhasil dibuat. Silakan masuk.";
                header("Location: login.php"); // Redirect ke halaman login setelah berhasil daftar
                exit();
            } else {
                $error_message = "Terjadi kesalahan saat mendaftar.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Daftar Akun</title>
    <link rel="stylesheet" href="style/login_daftar.css"> <!-- Pastikan file CSS ini ada -->
</head>
<body>
    <div class="wrapper">
        <form action="daftar.php" method="POST">
            <h2>Daftar Akun</h2>
            <div class="input-field">
                <input type="text" name="username" required placeholder=" ">
                <label>Nama Pengguna</label>
            </div>
            <div class="input-field">
                <input type="email" name="email" required placeholder=" ">
                <label>Email</label>
            </div>
            <div class="input-field">
                <input type="password" name="password" required placeholder=" ">
                <label>Kata Sandi</label>
            </div>
            <div class="input-field">
                <input type="password" name="confirm_password" required placeholder=" ">
                <label>Konfirmasi Kata Sandi</label>
            </div>
            <button type="submit">Daftar</button>
            <?php if (isset($error_message)): ?>
                <div class="alert error show"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <?php if (isset($success_message)): ?>
                <div class="alert success show"><?php echo $success_message; ?></div>
            <?php endif; ?>
        </form>
        <p>Sudah punya akun? <a href="login.php">Masuk</a></p>
    </div>

    <script>
        // JavaScript untuk menghilangkan alert setelah beberapa detik
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.classList.remove('show');
            }, 3000); // Menghilangkan alert setelah 3 detik
        });
    </script>
</body>
</html>