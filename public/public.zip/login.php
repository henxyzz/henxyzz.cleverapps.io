<?php
// login.php

// Termasuk file konfigurasi
include('config.php');

$error_message = '';

// Memulai sesi jika belum dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Memeriksa jika form login disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Menyiapkan query untuk mencari user berdasarkan username
    $stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Verifikasi password jika user ditemukan
    if ($user && password_verify($password, $user['password'])) {
        // Jika login berhasil, simpan sesi
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        // Redirect ke halaman dashboard setelah login berhasil
        header('Location: menu.php');
        exit();
    } else {
        // Jika username atau password salah
        $error_message = 'Username atau password salah.';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Portal AI Login</title>
  <link rel="stylesheet" href="style/login_daftar.css"> <!-- Pastikan file CSS ini ada -->
</head>
<body>
  <!-- Alert Messages -->
  <?php if ($error_message): ?>
      <div class="alert error show"><?php echo $error_message; ?></div>
  <?php endif; ?>
  <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
      <div class="alert show">Login berhasil!</div>
  <?php endif; ?>

  <div class="wrapper">
    <form action="login.php" method="post">
      <h2>Login</h2>
      <div class="input-field">
        <input type="text" name="username" required placeholder=" ">
        <label>Masukkan username</label>
      </div>
      <div class="input-field">
        <input type="password" name="password" required placeholder=" ">
        <label>Masukkan password</label>
      </div>
      <div class="forget">
        <label for="remember">
          <input type="checkbox" name="remember" id="remember">
          <p>Ingat saya</p>
        </label>
      </div>
      <button type="submit">Login</button>
      <div class="register">
        <p>Tidak punya akun? <a href="daftar.php">Daftar</a></p>
      </div>
    </form>
  </div>

  <!-- JavaScript untuk menghilangkan alert setelah beberapa detik -->
  <script>
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.classList.remove('show');
        }, 3000); // Menghilangkan alert setelah 3 detik
    });
  </script>
</body>
</html>